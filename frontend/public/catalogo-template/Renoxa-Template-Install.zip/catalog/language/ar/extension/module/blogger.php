<?php
// Heading 
$_['heading_title']    = 'أحدث مدونة';
$_['blogsub_title']    = 'جميع المشاركات الأخيرة من wbBlog';

// Text
$_['text_read_more']   = 'اقرأ أكثر';
$_['text_date_added']  = 'تم إضافة التاريخ:';
$_['entry_comment']       = 'تعليقات';
$_['text_comment']   = 'ترك تعليقات';

// Button
$_['button_all_blogs'] = 'انظر جميع المدونات';