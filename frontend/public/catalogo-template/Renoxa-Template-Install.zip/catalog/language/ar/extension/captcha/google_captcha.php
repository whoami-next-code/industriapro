<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Text
$_['text_captcha'] = 'التحقق';

// Entry
$_['entry_captcha'] = 'يرجى إكمال التحقق من صحة الاختبار أدناه';

// Error
$_['error_captcha'] = 'التحقق غير صحيح !';
