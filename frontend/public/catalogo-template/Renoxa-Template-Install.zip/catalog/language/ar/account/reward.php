<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'نقاط الكافآت الخاص بك';
$_['cheading_title']      = 'نقاط الكافآت الخاص بك';

// Column
$_['column_date_added']  = 'تاريخ الاضافة';
$_['column_description'] = 'الوصف';
$_['column_points']      = 'النقاط';

// Text
$_['text_account']       = 'الحساب';
$_['text_reward']        = 'نقاط المكافآت';
$_['text_total']         = 'إجمالي النقاط :';
$_['ctext_empty']         = 'لا يوجد لديك نقاط مكافآت !';