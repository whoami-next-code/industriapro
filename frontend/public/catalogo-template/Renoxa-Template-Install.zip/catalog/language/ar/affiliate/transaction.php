<?php
//  Website: WWW.OpenCartArab.com
//  E-Mail : info@OpenCartArab.com

// Heading
$_['heading_title']      = 'رصيدك';

// Column
$_['column_date_added']  = 'تاريخ الإضافة';
$_['column_description'] = 'الوصف';
$_['column_amount']      = 'الرصيد (%s)';

// Text
$_['text_account']       = 'الحساب';
$_['text_transaction']   = 'رصيدك';
$_['text_balance']       = 'رصيدك الحالي هو:';
$_['text_empty']         = 'لا يوجد لديك رصيد!';