<?php

// Heading
$_['heading_title']     = 'Webi Quick View';

// Text
$_['text_extension']    = 'Extensions';
$_['text_success']      = 'Success: You have modified HTML Content module!';
$_['text_edit']         = 'Edit QuickView Module';

// Entry
$_['entry_name']        = 'Module Name';
$_['entry_title']       = 'Heading Title';
$_['entry_description'] = 'Description';
$_['entry_enable_social'] = 'Enable Social Login';
$_['entry_status']      = 'Status';
$_['enable_style']	    = 'Enable Own Css';
$_['text_guide']		= 'Guide';
?>